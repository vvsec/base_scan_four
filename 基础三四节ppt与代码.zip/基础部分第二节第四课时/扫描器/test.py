count = -1
for count, line in enumerate(open('dirs.txt', 'r', encoding='UTF-8')):
    print(count,line)
count += 1