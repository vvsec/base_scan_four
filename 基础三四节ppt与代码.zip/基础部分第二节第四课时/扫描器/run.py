# -*- coding:UTF-8 -*-
from PyQt5.QtWidgets import QApplication,QMainWindow,QWidget,QTableWidgetItem
from concurrent.futures import ThreadPoolExecutor
from PyQt5.QtCore import QThread,pyqtSignal,pyqtSlot
import requests
import scan
import sys
import time
import re
from requests.packages.urllib3.exceptions import InsecureRequestWarning
# 禁用安全请求警告
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class Main(QMainWindow,scan.Ui_Form):   #图像界面窗口
    def __init__(self):
        super(Main, self).__init__()
        self.setupUi(self)
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setRowCount(2000000)
    @pyqtSlot()
    def on_pushButton_clicked(self):
        print('pushButton按下了')
        self.targeturl = self.textEdit.toPlainText()
        self.thread_num = self.textEdit_2.toPlainText()
        self.scan = scanit(self.targeturl,self.thread_num)
        self.scan.singout.connect(self.look)
        self.scan.start()
        print(self.targeturl,self.thread_num)
    def look(self,text):
        # print(type(text))
        # print(text)
        targeturl = text[0][0]
        payload = text[0][1]
        stu = text[0][2]
        title = text[0][3]
        num_tr = text[1]
        per = text[2]
        targeturl_str = QTableWidgetItem(targeturl)
        payload_str = QTableWidgetItem(payload)
        stu_str = QTableWidgetItem(stu)
        title_str = QTableWidgetItem(title)
        # num_tr_str = QTableWidgetItem(num_tr)
        self.tableWidget.setItem(num_tr, 0, targeturl_str)
        self.tableWidget.setItem(num_tr, 1, payload_str)
        self.tableWidget.setItem(num_tr, 2, stu_str)
        self.tableWidget.setItem(num_tr, 3, title_str)
        self.progressBar.setProperty("value", per)
class scanit(QThread):
    singout = pyqtSignal(list)
    def __init__(self,url,num_thread):
        super(scanit,self).__init__()
        self.tar = url
        self.thd = num_thread
    def scan(self,payload):
        header = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36',
            'Connection': 'keep-alive',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
        try:
            payload = payload.strip()
            req = requests.get(url=self.tar + '/' + payload, headers=header, verify=False, timeout=3)
            res = req.status_code
            res_content = req.text
            pattern = '<title>.+</title>'
            match = re.search(pattern, res_content)
            if match:
                title = match.group().replace('<title>', '').replace('</title>', '')
                # print(title)
                # list_exam = [self.tar, payload, res, title]
                # print(res)
                return  [self.tar, payload, res, title]
            else:
                pass
        except Exception as e:
            print(e)
    def run(self):
        payload_num = 0
        payload_list = []
        count = -1
        for count, line in enumerate(open('dirs.txt', 'r',encoding='UTF-8')):
            pass
        count += 1
        for payload in open('dirs.txt', 'r'):
            if len(payload_list) < int(self.thd):
                payload_list.append(payload)
            elif len(payload_list) == int(self.thd):
                with ThreadPoolExecutor(int(self.thd)) as cur:
                    s = cur.map(self.scan,payload_list)
                    for detail in s:
                        if detail == None:
                            pass
                        else:
                            print(payload_num,count)
                            per = payload_num / count
                            print(per)
                            per = per * 25
                            self.singout.emit([detail,payload_num,per])
                            payload_num +=1
                            print(detail)

            elif len(payload_list) > int(self.thd):
                payload_list.clear()
            else:
                pass
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Main()
    window.show()
    app.exec()