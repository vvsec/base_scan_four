# -*- coding:UTF-8 -*-

from PyQt5.QtWidgets import QApplication,QMainWindow,QWidget,QTableWidgetItem
from concurrent.futures import ThreadPoolExecutor
from PyQt5.QtCore import QThread,pyqtSignal,pyqtSlot
import deocdeencode
import sys
import time


class Main(QMainWindow):   #图像界面窗口
    def __init__(self):
        super(Main, self).__init__()
        self.mainui = deocdeencode.Ui_Form()
        self.mainui.setupUi(self)
        self.sjgal = changetext()
        # self.mainui.textEdit_8.textEdited[str].connect(lambda: self.onChange())
        # self.sjgal.qsingl.connect(self.keyboardevent)

    # def keyboardevent(self,text):
    #     # urlencode = self.mainui.textEdit_8
    #     # urldecode = self.mainui.textEdit_13
    #     # base64encode = self.mainui.textEdit_10
    #     # base64decode = self.mainui.textEdit_14
    #     # base16encode = self.mainui.textEdit_11
    #     # base16decode = self.mainui.textEdit_9
    #     # utf8encode = self.mainui.textEdit_12
    #     # utf8decode = self.mainui.textEdit_7
    #     print(text)



class changetext(object):
    qsingl = pyqtSignal(str)
    def __init__(self):
        super(changetext,self).__init__()

    def onChange(self):
        urlencode = self.mainui.textEdit_8
        urldecode = self.mainui.textEdit_13
        base64encode = self.mainui.textEdit_10
        base64decode = self.mainui.textEdit_14
        base16encode = self.mainui.textEdit_11
        base16decode = self.mainui.textEdit_9
        utf8encode = self.mainui.textEdit_12
        utf8decode = self.mainui.textEdit_7
        if urlencode != None:
            self.qsingl.emit('test')
        else:
            pass




"""
使用代码：
 self.label.grabKeyboard()   #控件开始捕获键盘

#只有控件开始捕获键盘，控件的键盘事件才能收到消息. 

self.label.releaseKeyboard()      #停止捕获键盘 
"""




if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Main()
    window.show()
    app.exec()