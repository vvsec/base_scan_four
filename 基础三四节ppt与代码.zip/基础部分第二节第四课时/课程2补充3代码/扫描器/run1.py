# -*- coding:UTF-8 -*-

from PyQt5.QtWidgets import QApplication,QMainWindow,QWidget,QTableWidgetItem
from concurrent.futures import ThreadPoolExecutor
from PyQt5.QtCore import QThread,pyqtSignal
import dirscan
import requests
import re
import sys
import time


class Main(QMainWindow):   #图像界面窗口
    def __init__(self):
        super(Main, self).__init__()
        self.mainui = dirscan.Ui_Form()
        self.mainui.setupUi(self)


class scanurl(QThread):
    sinOut = pyqtSignal(list)
    def __init__(self,targetUrl,thread_num):
        super(scanurl, self).__init__()
        self.targetUrl = targetUrl
        self.thread_num = thread_num
        self.Main = Main()
        self.Main.show()
        self.sinOut.connect(self.refresh)

    def refresh(self,list_like):
        self.Main.mainui.textEdit.append(str(list_like))

    def scan(self,payload):
        print("payload",payload)
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36',
                   'Connection': 'keep-alive',
                   'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
        scanreq = requests.get(url=self.targetUrl + payload, headers=headers, timeout=3, verify=False)
        urltitle = scanreq.text
        url_status = scanreq.status_code
        pattern = '<title>.+</title>'
        title_match = re.search(pattern, urltitle)
        title_match = title_match.group().replace('<title>', '').replace('</title>', '')
        title = title_match
        # print(url_status,title)
        if url_status == 200:
            return [url_status,title]
        elif url_status == 302:
            return [url_status,title]
        else:
            pass

    def run(self):
        dirs = []
        time.sleep(2)
        for dic in open('dirs.txt','r'):
            dic = dic.strip()
            dirs.append(dic)
        payload_num = 0
        payload_list = []
        print("dirs",dirs)
        for payload in dirs:
            payload_num += 1
            if payload_num > self.thread_num:
                payload_num = 0
                payload_list.clear()
            elif payload_num < self.thread_num:
                payload_list.append(payload)
            elif payload_num ==  self.thread_num:
                with ThreadPoolExecutor(self.thread_num) as executor1:
                        s = executor1.map(self.scan,payload_list)
                for detail in s:
                    if detail == None:
                        pass
                    else:
                        print("detail",detail)
                        self.sinOut.emit(detail)
            else:
                pass


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ss = scanurl('http://basetest.m9kj-team.com:9999', 8)
    ss.start()
    app.exec()
