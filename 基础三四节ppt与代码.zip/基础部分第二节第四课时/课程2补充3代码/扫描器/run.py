# -*- coding:UTF-8 -*-

from PyQt5.QtWidgets import QApplication,QMainWindow,QWidget,QTableWidgetItem
from concurrent.futures import ThreadPoolExecutor
from PyQt5.QtCore import QThread,pyqtSignal,pyqtSlot
import dirscan
import requests
import re
import sys
import time

#http://basetest.m9kj-team.com:9999
class Main(QMainWindow):   #图像界面窗口
    def __init__(self):
        super(Main, self).__init__()
        self.mainui = dirscan.Ui_Form()
        self.mainui.setupUi(self)
    @pyqtSlot()
    def on_pushButton_clicked(self):
        self.tar = self.mainui.textEdit.toPlainText()
        self.tnum = self.mainui.textEdit_2.toPlainText()
        self.thread = scanurl(self.tar,self.tnum)
        self.thread.sinOut.connect(self.refresh)
        self.thread.singal.connect(self.process)
        self.thread.start()

    def process(self,per_process):
        print(per_process)
        self.processbar = self.mainui.progressBar
        self.processbar.setProperty("value", int(per_process))

    def refresh(self,list_like):
        print(list_like)
        runtime = int(list_like[0])
        targeturl = list_like[1][0]
        payload = list_like[1][1]
        status = str(list_like[1][2])
        title = list_like[1][3]
        self.mainui.tableWidget.setRowCount(200)
        self.mainui.tableWidget.setColumnCount(4)
        targeturl_str = QTableWidgetItem(targeturl)
        payload_str = QTableWidgetItem(payload)
        status_str = QTableWidgetItem(status)
        title_str = QTableWidgetItem(title)
        self.mainui.tableWidget.setItem(runtime, 0, targeturl_str)
        self.mainui.tableWidget.setItem(runtime, 1, payload_str)
        self.mainui.tableWidget.setItem(runtime, 2, status_str)
        self.mainui.tableWidget.setItem(runtime, 3, title_str)

class scanurl(QThread):
    sinOut = pyqtSignal(list)
    singal = pyqtSignal(int)
    def __init__(self,targetUrl,thread_num):
        super(scanurl, self).__init__()
        self.targetUrl = targetUrl
        self.thread_num = int(thread_num)

    def scan(self,payload):
        print(payload)
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36',
                   'Connection': 'keep-alive',
                   'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'}
        scanreq = requests.get(url=self.targetUrl + payload, headers=headers, timeout=3, verify=False)
        urltitle = scanreq.text
        url_status = scanreq.status_code
        pattern = '<title>.+</title>'
        title_match = re.search(pattern, urltitle)
        title_match = title_match.group().replace('<title>', '').replace('</title>', '')
        title = title_match
        # print(url_status,title)
        if url_status == 200:
            return [self.targetUrl,payload,url_status,title]
        elif url_status == 302:
            return [self.targetUrl,payload,url_status,title]
        else:
            pass

    def run(self):
        dirs = []
        for dic in open('dirs.txt','r'):
            dic = dic.strip()
            dirs.append(dic)
        payload_num = 0
        process_num = 0
        dotime = 0
        payload_list = []
        print(dirs)
        for payload in dirs:
            process_num += 1
            per_process = process_num / len(dirs)
            per_process = round(per_process * 100)
            self.singal.emit(per_process)
            payload_num += 1
            if payload_num > self.thread_num:
                payload_num = 0
                payload_list.clear()
            elif payload_num < self.thread_num:
                payload_list.append(payload)
            elif payload_num == self.thread_num:
                with ThreadPoolExecutor(self.thread_num) as executor1:
                        s = executor1.map(self.scan,payload_list)
                for detail in s:
                    if detail == None:
                        pass
                    else:
                        list_like = [str(dotime),detail]
                        self.sinOut.emit(list_like)
                        dotime += 1
            else:
                pass


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ss = Main()
    ss.show()
    app.exec()
