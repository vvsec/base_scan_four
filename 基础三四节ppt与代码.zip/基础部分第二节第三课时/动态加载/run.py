# -*- coding:UTF-8 -*-
from PyQt5 import Qt
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QApplication,QMainWindow
import loading
import sys


class newwindows(QMainWindow,loading.Ui_Form):
    def __init__(self):
        super(newwindows,self).__init__()
        # self.windows = loading.Ui_Form()
        self.setupUi(self)

    def mousePressEvent(self, event):
        try:
            if event.button() == Qt.Qt.LeftButton:
                self.m_flag = True
                self.m_Position = event.globalPos() - self.pos()  # 获取鼠标相对窗口的位置
                event.accept()
                self.setCursor(Qt.QCursor(Qt.Qt.OpenHandCursor))  # 更改鼠标图标
            else:
                print('111')
        except Exception as e:
            print(e)
    def mouseMoveEvent(self, QMouseEvent):
        if Qt.Qt.LeftButton and self.m_flag:
            self.move(QMouseEvent.globalPos() - self.m_Position)  # 更改窗口位置
            QMouseEvent.accept()

    def mouseReleaseEvent(self, QMouseEvent):
        self.m_flag = False
        self.setCursor(Qt.QCursor(Qt.Qt.ArrowCursor))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    newwindow = newwindows()
    newwindow.show()
    QTimer.singleShot(5000, app.quit)
    # time.sleep(3)
    # newwindow.close()
    sys.exit(app.exec())
