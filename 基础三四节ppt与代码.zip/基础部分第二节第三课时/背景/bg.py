# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\安全牛\第二节课\第二课时\直播\bg.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(681, 512)
#         Form.setStyleSheet("background-image: url(:/bg/150.jpg);border-radius: 100px;\n"
# "")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
import bg_rc
