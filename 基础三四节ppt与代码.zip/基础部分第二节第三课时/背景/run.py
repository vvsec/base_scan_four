# -*- coding:UTF-8 -*-

from PyQt5.QtWidgets import QApplication,QMainWindow
from bg import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPainter, QPixmap
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import pyqtSlot
import sys

class newwindows(QMainWindow,Ui_Form):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setupUi(self)
    # @pyqtSlot()
    def paintEvent(self, event):
        painter = QPainter()
        painter.begin(self)
        painter.setRenderHint(QPainter.Antialiasing)
        # // 反走样
        painter.setPen(Qt.NoPen)
        painter.drawPixmap(0, 0, 681, 512, QPixmap("150.jpg"))
        painter.end()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    newwindow = newwindows()
    newwindow.show()
    sys.exit(app.exec())

#作业 ：
#点击按钮如何生成C段呢？
#提示 信号槽，装饰器 ，Qmessage Box