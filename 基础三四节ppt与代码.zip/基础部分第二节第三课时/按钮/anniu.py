# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\安全牛\第二节课\第二课时\直播\按钮\anniu.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(681, 397)
        self.pushButton = QtWidgets.QPushButton(Form)
        self.pushButton.setGeometry(QtCore.QRect(210, 250, 291, 111))
#         self.pushButton.setStyleSheet("color: rgb(255, 47, 47);border-radius: 30px;\n"
# "border:5px solid red;\n"
# "background-color: rgb(255, 255, 127);")
        self.pushButton.setStyleSheet("""
            QPushButton{
            color: rgb(255, 47, 47);
            border-radius: 30px;
            border:5px solid red;
            background-color: rgb(255, 255, 127);
            }
            QPushButton:hover {
    background-color: yellow;
    border-style: inset;
    border-radius: 30px;
    border:5px solid red;
    }
    QPushButton:pressed {
    background-color: blue;
    border-style: inset;
        border-radius: 30px;
    border:5px solid red;
    }
        """)
        self.pushButton.setObjectName("pushButton")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.pushButton.setText(_translate("Form", "安全牛扫描器开发系列课程-VVSEC"))
import anniu_rc
