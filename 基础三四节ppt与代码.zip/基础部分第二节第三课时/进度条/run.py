# -*- coding:UTF-8 -*-

from PyQt5.QtWidgets import QApplication,QMainWindow
from loading import *
from PyQt5.QtCore import pyqtSlot,QBasicTimer
import sys

class newwindows(QMainWindow,Ui_Form):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.step = 0
        self.timer = QBasicTimer()
    @pyqtSlot()
    def on_pushButton_clicked(self):
        self.doAction()
    def timerEvent(self,e):
        if self.step >= 100:
            self.timer.stop()
            self.pushButton.setText('完成')
            self.progressBar.setProperty("value", 0)
            self.Form.close
        self.step = self.step + 1
        self.progressBar.setProperty("value", self.step)
    def doAction(self):
        if self.timer.isActive():
            self.timer.stop()
            self.pushButton.setText('开始')
        else:
            self.timer.start(100, self)
            self.pushButton.setText('停止')



if __name__ == '__main__':
    app = QApplication(sys.argv)
    newwindow = newwindows()
    newwindow.show()
    sys.exit(app.exec())

#作业 ：
#点击按钮如何生成C段呢？
#提示 信号槽，装饰器 ，Qmessage Box